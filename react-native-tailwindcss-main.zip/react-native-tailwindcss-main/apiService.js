import axios from 'axios';

const API_BASE_URL = 'http://192.168.0.200:5000'; // Replace with your backend URL

export async function login(username, password) {
  try {
      const response = await axios.post(`${API_BASE_URL}/login`, {
          username: username,
          password: password
      });

      return response.data; // Expecting response to include a success message and user_id
  } catch (error) {
      console.error('Login error:', error);
      throw error;
  }
}

export async function signup(username, email, password) {
    try {
        const response = await axios.post(`${API_BASE_URL}/signup`, {
            username: username,
            email: email,
            password: password
        });

        return response.data; // Expecting response to include a success message and user_id
    } catch (error) {
        console.error('Signup error:', error);
        throw error;
    }
}


// Fetch tour guides associated with the logged-in user
export const getTourGuides = async (user_id) => {
  try {
    const response = await axios.get(`${API_BASE_URL}/tour_guides`, {
      params: { user_id }
    });
    return response.data;
  } catch (error) {
    console.error('Error fetching tour guides:', error);
    throw error;
  }
};

// Add a new tour guide
export const addTourGuide = async (name, email, contact, busy_dates, user_id) => {
  try {
    const response = await axios.post(`${API_BASE_URL}/tour_guide`, {
      name,
      email,
      contact,
      busy_dates,
      user_id  // Pass the user_id to associate the tour guide with the logged-in user
    });
    return response.data;
  } catch (error) {
    console.error('Error adding tour guide:', error);
    throw error;
  }
};

// Update a tour guide
export const updateTourGuide = async (id, name, email, contact, busy_dates, user_id) => {
  try {
    const response = await axios.put(`${API_BASE_URL}/tour_guide/${id}`, {
      name,
      email,
      contact,
      busy_dates,
      user_id  // Pass the user_id to ensure only the correct user can update the tour guide
    });
    return response.data;
  } catch (error) {
    console.error('Error updating tour guide:', error);
    throw error;
  }
};

// Delete a tour guide
export const deleteTourGuide = async (id, user_id) => {
  try {
    const response = await axios.delete(`${API_BASE_URL}/tour_guide/${id}`, {
      data: { user_id }  // Pass the user_id to ensure only the correct user can delete the tour guide
    });
    return response.data;
  } catch (error) {
    console.error('Error deleting tour guide:', error);
    throw error;
  }
};
