import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, Image, Alert } from 'react-native';
import 'nativewind';

export default function LoginScreen({ navigation }) {
  const [username, setUsername] = useState('');  // State to hold the username
  const [password, setPassword] = useState('');  // State to hold the password

  const handleLogin = () => {
    // You can implement the backend login logic later
    Alert.alert('Login Clicked', 'Backend login logic goes here.');
  };

  return (
    <View className="items-center justify-center flex-1 bg-gray-100">
      <Image
        source={require('../assets/company-logo.png')}
        style={{ width: 205, height: 46 }} // Adjust width and height to fit the logo size
        resizeMode="contain" // Ensure the image scales properly
        className="mb-8"
      />
      <Text className="mb-4 text-3xl font-bold text-gray-800">GuideAve</Text>

      <TextInput
        className="w-4/5 h-12 px-4 mb-4 bg-white border border-gray-300 rounded-lg"
        placeholder="Username"
        placeholderTextColor="#888"
        value={username}  // Bind the TextInput value to the username state
        onChangeText={setUsername}  // Update the state when user inputs text
      />

      <TextInput
        className="w-4/5 h-12 px-4 mb-4 bg-white border border-gray-300 rounded-lg"
        placeholder="Password"
        placeholderTextColor="#888"
        secureTextEntry={true}
        value={password}  // Bind the TextInput value to the password state
        onChangeText={setPassword}  // Update the state when user inputs text
      />

      <TouchableOpacity
        className="items-center justify-center w-4/5 h-12 mb-4 bg-blue-500 rounded-lg"
        onPress={handleLogin}  // Call handleLogin when the button is pressed
      >
        <Text className="text-lg font-semibold text-white">Login</Text>
      </TouchableOpacity>

      <TouchableOpacity onPress={() => navigation.navigate('Signup')}>
        <Text className="font-semibold text-blue-500">Don't have an account? Signup</Text>
      </TouchableOpacity>
    </View>
  );
}
