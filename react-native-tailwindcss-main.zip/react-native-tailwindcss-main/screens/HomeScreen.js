import React, { useState } from "react";
import { View, Text, TouchableOpacity } from "react-native";
import "nativewind";
import { useNavigation } from '@react-navigation/native';
import { Calendar } from 'react-native-calendars';

export default function HomeScreen() {
  const [selectedDates, setSelectedDates] = useState({});
  const navigation = useNavigation();
  const userName = "Eranda"; // Replace with dynamic name

  // Function to handle selecting a range of dates
  const onDayPress = (day) => {
    const newDates = { ...selectedDates };
    if (newDates[day.dateString]) {
      delete newDates[day.dateString]; // Toggle date selection
    } else {
      newDates[day.dateString] = { selected: true, marked: true };
    }
    setSelectedDates(newDates);
  };

  return (

    <View className="flex-1 p-4 bg-gray-100">
      <View className="flex-row items-center justify-between mb-4">
        <Text className="text-2xl font-bold">Welcome, {userName}</Text>
        <TouchableOpacity
          className="items-center justify-center w-10 h-10 bg-blue-500 rounded-full"
          onPress={() => navigation.navigate("Profile")}
        >
          <Text className="text-xl font-bold text-white">
            {userName.charAt(0)}
          </Text>
        </TouchableOpacity>
      </View>

      <Calendar
        onDayPress={onDayPress}
        markedDates={selectedDates}
        markingType={"simple"}
        theme={{
          selectedDayBackgroundColor: "#00adf5",
          todayTextColor: "#00adf5",
          dayTextColor: "#2d4150",
          arrowColor: "orange",
        }}
      />

      <TouchableOpacity
        className="px-4 py-2 mt-4 bg-blue-500 rounded-lg"
        onPress={() => {
          // Placeholder for backend functionality to update selected dates
          console.log('Update button pressed. Implement backend logic here.');
        }}
      >
        <Text className="text-lg text-center text-white">Update</Text>
      </TouchableOpacity>
    </View>
  );
}
