import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, Image, Alert } from 'react-native';
import 'nativewind';

export default function SignupScreen({ navigation }) {
  const [username, setUsername] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');

  const handleSignup = () => {
    if (password !== confirmPassword) {
      Alert.alert('Error', 'Passwords do not match.');
      return;
    }

    // Placeholder for backend signup logic
    console.log('Signup button pressed. Implement backend logic here.');

    // Navigate to login on successful signup (after backend integration)
    navigation.navigate('Login');
  };

  return (
    <View className="items-center justify-center flex-1 bg-gray-100">
      <Image
        source={require('../assets/company-logo.png')}
        style={{ width: 205, height: 46 }}
        resizeMode="contain"
        className="mb-8"
      />
      <Text className="mb-4 text-3xl font-bold text-gray-800">GuideAve</Text>

      <TextInput
        className="w-4/5 h-12 px-4 mb-4 bg-white border border-gray-300 rounded-lg"
        placeholder="Username"
        placeholderTextColor="#888"
        value={username}
        onChangeText={setUsername}
      />

      <TextInput
        className="w-4/5 h-12 px-4 mb-4 bg-white border border-gray-300 rounded-lg"
        placeholder="Email"
        placeholderTextColor="#888"
        value={email}
        onChangeText={setEmail}
      />

      <TextInput
        className="w-4/5 h-12 px-4 mb-4 bg-white border border-gray-300 rounded-lg"
        placeholder="Password"
        placeholderTextColor="#888"
        secureTextEntry={true}
        value={password}
        onChangeText={setPassword}
      />

      <TextInput
        className="w-4/5 h-12 px-4 mb-4 bg-white border border-gray-300 rounded-lg"
        placeholder="Confirm Password"
        placeholderTextColor="#888"
        secureTextEntry={true}
        value={confirmPassword}
        onChangeText={setConfirmPassword}
      />

      <TouchableOpacity
        className="items-center justify-center w-4/5 h-12 mb-4 bg-blue-500 rounded-lg"
        onPress={handleSignup}
      >
        <Text className="text-lg font-semibold text-white">Signup</Text>
      </TouchableOpacity>

      <TouchableOpacity onPress={() => navigation.navigate('Login')}>
        <Text className="font-semibold text-blue-500">Already have an account? Login</Text>
      </TouchableOpacity>
    </View>
  );
}
