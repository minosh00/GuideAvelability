import React, { useState, useEffect } from 'react';
import { View, Text, Button, Platform } from 'react-native'; // Import Button from 'react-native'
import RNPickerSelect from 'react-native-picker-select'; // Dropdown picker for guides
import DateTimePicker from '@react-native-community/datetimepicker'; // Updated date picker
import { getTourGuides } from '../apiService'; // Import the API service

const ExecutiveScreen = () => {
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [selectedGuide, setSelectedGuide] = useState(null);
  const [guides, setGuides] = useState([]);
  const [availableDates, setAvailableDates] = useState([]);
  const [showDatePicker, setShowDatePicker] = useState(false);

  // Fetch guides on component mount
  useEffect(() => {
    const fetchGuides = async () => {
      try {
        const result = await getTourGuides(); // Fetch guides list
        setGuides(result);
      } catch (error) {
        console.error('Error fetching guides:', error);
      }
    };
    fetchGuides();
  }, []);

  // When a guide is selected, fetch their available dates
  const handleGuideSelect = (guideId) => {
    setSelectedGuide(guideId);
    const selectedGuide = guides.find((guide) => guide.id === guideId);
    setAvailableDates(selectedGuide?.busy_dates || []);
  };

  // Handle date picker change
  const onDateChange = (event, selectedDate) => {
    setShowDatePicker(false); // Hide the date picker after selection
    if (selectedDate) {
      setSelectedDate(selectedDate);
    }
  };

  return (
    <View style={{ flex: 1, padding: 20,paddingTop:50 }}>
      <Text style={{ fontSize: 18, fontWeight: 'bold', marginBottom: 16 }}>
        Select a Guide and Date
      </Text>

      {/* Guide Dropdown */}
      <RNPickerSelect
        onValueChange={(value) => handleGuideSelect(value)}
        items={guides.map((guide) => ({
          label: guide.name,
          value: guide.id,
        }))}
        placeholder={{ label: 'Select a Guide', value: null }}
      />

      {/* Date Picker */}
      <View style={{ marginTop: 20 }}>
        {Platform.OS === 'android' && (
          <Button title="Select Date" onPress={() => setShowDatePicker(true)} />
        )}

        {(Platform.OS === 'ios' || showDatePicker) && (
          <DateTimePicker
            value={selectedDate}
            mode="date"
            display="default"
            onChange={onDateChange}
            style={{ width: 200 }}
          />
        )}
      </View>

      {/* Display available dates */}
      <Text style={{ marginTop: 16 }}>
        {availableDates.includes(selectedDate.toISOString().split('T')[0])
          ? 'Guide is available on this date.'
          : 'Guide is not available on this date.'}
      </Text>
    </View>
  );
};

export default ExecutiveScreen;
