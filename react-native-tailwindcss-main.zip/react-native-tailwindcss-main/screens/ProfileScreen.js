import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, ScrollView, Image } from 'react-native';
import { MaterialIcons, FontAwesome } from '@expo/vector-icons';
import * as ImagePicker from 'expo-image-picker';
import "nativewind";

export default function ProfileScreen({ navigation }) {
  const [name, setName] = useState('Eranda Dhanushka');
  const [email, setEmail] = useState('eranda@gmail.com');
  const [contact, setContact] = useState('+94775459313');
  const [profilePicture, setProfilePicture] = useState(null);
  const [isEditing, setIsEditing] = useState(false); // State to toggle edit mode

  const pickImage = async () => {
    let result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      allowsEditing: true,
      aspect: [1, 1],
      quality: 1,
    });

    if (!result.canceled) {
      setProfilePicture(result.assets[0].uri);
    }
  };

  const saveProfile = () => {
    setIsEditing(false);
    // Add logic to save the profile details if needed
  };

  return (
    <ScrollView className="flex-1 p-4 bg-gray-100">
      <View className="items-center mb-6">
        <View className="relative">
          <Image
            source={
              profilePicture
                ? { uri: profilePicture }
                : require('../assets/default-profile.jpg')
            }
            className="w-32 h-32 rounded-full"
          />
          <TouchableOpacity
            onPress={pickImage}
            className="absolute bottom-0 right-0 p-1 bg-white rounded-full"
          >
            <MaterialIcons name="camera-alt" size={24} color="gray" />
          </TouchableOpacity>
        </View>
        <TextInput
          className="mt-4 text-lg font-semibold text-center"
          value={name}
          onChangeText={setName}
          editable={isEditing} // Editable only in edit mode
        />
      </View>

      <View className="px-6 mb-4">
        <Text className="text-lg font-semibold">Personal Info</Text>

        <View className="flex-row items-center mt-4">
          <FontAwesome name="phone" size={20} color="gray" />
          {isEditing ? (
            <TextInput
              className="ml-2 text-base text-gray-800 border-b border-gray-300"
              value={contact}
              onChangeText={setContact}
              keyboardType="phone-pad"
            />
          ) : (
            <Text className="ml-2 text-base text-gray-800">{contact}</Text>
          )}
        </View>

        <View className="flex-row items-center mt-4">
          <MaterialIcons name="email" size={20} color="gray" />
          {isEditing ? (
            <TextInput
              className="ml-2 text-base text-gray-800 border-b border-gray-300"
              value={email}
              onChangeText={setEmail}
              keyboardType="email-address"
            />
          ) : (
            <Text className="ml-2 text-base text-gray-800">{email}</Text>
          )}
        </View>
      </View>

      <TouchableOpacity
        className="items-center justify-center h-12 bg-blue-500 rounded-lg"
        onPress={isEditing ? saveProfile : () => setIsEditing(true)}
      >
        <Text className="text-lg font-semibold text-white">
          {isEditing ? 'Save Profile' : 'Edit Profile'}
        </Text>
      </TouchableOpacity>
    </ScrollView>
  );
}
