from flask import Flask, request, jsonify
from flask_sqlalchemy import SQLAlchemy
from flask_cors import CORS
from datetime import datetime
from werkzeug.security import generate_password_hash, check_password_hash  # For password hashing

app = Flask(__name__)
CORS(app)  # Add CORS configuration here

app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql+pymysql://root:@localhost/tour_guide_db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)

class User(db.Model):
    __tablename__ = 'Users'
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(100), nullable=False, unique=True)
    email = db.Column(db.String(100), nullable=False, unique=True)
    password = db.Column(db.String(100), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

class TourGuide(db.Model):
    __tablename__ = 'Tour_Guides'
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(100), nullable=False)
    contact = db.Column(db.String(15), nullable=False)
    busy_dates = db.Column(db.Text, nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    # New column to establish relationship with User
    user_id = db.Column(db.Integer, db.ForeignKey('Users.id'), nullable=False)

    # Relationship field (optional, allows easy access to the related User object)
    user = db.relationship('User', backref=db.backref('tour_guides', lazy=True))

# Creating the database tables inside an application context
with app.app_context():
    db.create_all()
@app.route(' ', methods=['POST'])
def signup():
    data = request.json
    username = data['username']
    email = data['email']
    password = generate_password_hash(data['password'], method='pbkdf2:sha256')

    user_exists = User.query.filter((User.username == username) | (User.email == email)).first()
    if user_exists:
        return jsonify({'message': 'User already exists!'}), 400

    # Create the user
    new_user = User(username=username, email=email, password=password)
    db.session.add(new_user)
    db.session.commit()

    # Create a basic tour guide record associated with the new user
    new_tour_guide = TourGuide(
        name='',  # Placeholder name, user can update this later
        email=email,  # Use the user's email as the initial tour guide email
        contact='',  # Placeholder contact, user can update this later
        busy_dates=None,  # No busy dates initially
        user_id=new_user.id  # Associate with the new user
    )
    db.session.add(new_tour_guide)
    db.session.commit()

    return jsonify({'message': 'User and basic tour guide record created successfully!', 'user_id': new_user.id}), 201

@app.route('/login', methods=['POST'])
def login():
    data = request.json
    username = data['username']
    password = data['password']

    user = User.query.filter_by(username=username).first()

    if not user or not check_password_hash(user.password, password):
        return jsonify({'message': 'Invalid username or password!'}), 401

    return jsonify({'message': 'Login successful!', 'user_id': user.id})

@app.route('/tour_guides', methods=['GET'])
def get_tour_guides():
    user_id = request.args.get('user_id')
    query = TourGuide.query
    if user_id:
        query = query.filter_by(user_id=user_id)
    tour_guides = query.all()
    
    return jsonify([{
        'id': tg.id,
        'name': tg.name,
        'email': tg.email,
        'contact': tg.contact,
        'busy_dates': tg.busy_dates.split(',') if tg.busy_dates else [],
        'user_id': tg.user_id
    } for tg in tour_guides])

@app.route('/tour_guide', methods=['POST'])
def add_ttour_guide():
    data = request.json
    new_tour_guide = TourGuide(
        name=data['name'],
        email=data['email'],
        contact=data['contact'],
        busy_dates=','.join(data['busy_dates']) if 'busy_dates' in data else None,
        user_id=data['user_id']  # Associate with the logged-in user
    )
    db.session.add(new_tour_guide)
    db.session.commit()
    return jsonify({'message': 'Tour guide added successfully!'})

@app.route('/tour_guide/<int:id>', methods=['PUT'])
def update_tour_guide(id):
    data = request.json
    tour_guide = TourGuide.query.get(id)
    if not tour_guide:
        return jsonify({'message': 'Tour guide not found!'}), 404

    # Ensure that the tour guide belongs to the user attempting to update it
    if tour_guide.user_id != data['user_id']:
        return jsonify({'message': 'Unauthorized access!'}), 403

    tour_guide.name = data.get('name', tour_guide.name)
    tour_guide.email = data.get('email', tour_guide.email)
    tour_guide.contact = data.get('contact', tour_guide.contact)
    tour_guide.busy_dates = ','.join(data['busy_dates']) if 'busy_dates' in data else tour_guide.busy_dates

    db.session.commit()
    return jsonify({'message': 'Tour guide updated successfully!'})

@app.route('/tour_guide/<int:id>', methods=['DELETE'])
def delete_tour_guide(id):
    data = request.json
    tour_guide = TourGuide.query.get(id)
    if not tour_guide:
        return jsonify({'message': 'Tour guide not found!'}), 404

    # Ensure that the tour guide belongs to the user attempting to delete it
    if tour_guide.user_id != data['user_id']:
        return jsonify({'message': 'Unauthorized access!'}), 403

    db.session.delete(tour_guide)
    db.session.commit()
    return jsonify({'message': 'Tour guide deleted successfully!'})

if __name__ == '__main__':
    app.run(host="0.0.0.0", port=5000, debug=True)
